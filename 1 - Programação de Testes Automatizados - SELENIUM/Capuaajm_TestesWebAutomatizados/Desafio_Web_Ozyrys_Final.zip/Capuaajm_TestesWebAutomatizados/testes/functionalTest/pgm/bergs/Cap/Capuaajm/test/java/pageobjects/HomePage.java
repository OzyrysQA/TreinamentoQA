package bergs.Cap.Capuaajm.test.java.pageobjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
    private WebDriver driver;
    private WebDriverWait wait;
    private LoginCadastroPage loginCadastroPage;
    private TransferenciaPage transferenciaPage;
    
    // Mapeando Elementos da HomePage
    
    // Elementos da Mensagem de Bem-vindo!
    private By textNameP = By.id("textName");
    
    // Elementos do Saldo da Conta
    private By balanceText = By.xpath("//p[@id='textBalance']/span");
    
    // Elementos do Menu
    private By transferButton = By.id("btn-TRANSFER�NCIA");
    
    public HomePage(WebDriver driver) {
        this.driver = driver;
        // Utiliza espera impl�cita para driver aguardar at� 10s  
        wait = new WebDriverWait(driver,Duration.ofSeconds(10));

    }
    
    // Pega o nome do usu�rio na mensagem de bem vindo na p�gina de login da HomePage
    public String getTextNameHome()
    {
        // Aguarda at� p com nome aparecer
        wait.until(ExpectedConditions.visibilityOfElementLocated(textNameP));
        WebElement textNamePElement = driver.findElement(textNameP);
        return textNamePElement.getText();
        
    }
    
    // Pega  o saldo atual da conta
    public String getBalanceText() {
        // Aguarda at� que o texto do saldo esteja vis�vel
        WebElement balanceTextElement = wait.until(ExpectedConditions.visibilityOfElementLocated(balanceText));

        // Retorna o texto do elemento
        return balanceTextElement.getText();
    }
    
    public TransferenciaPage clickTransferButton() {
        WebElement transferButtonElement = driver.findElement(transferButton);
        transferButtonElement.click();
        transferenciaPage = new TransferenciaPage(driver);
        return transferenciaPage;
    }
    
    
}
