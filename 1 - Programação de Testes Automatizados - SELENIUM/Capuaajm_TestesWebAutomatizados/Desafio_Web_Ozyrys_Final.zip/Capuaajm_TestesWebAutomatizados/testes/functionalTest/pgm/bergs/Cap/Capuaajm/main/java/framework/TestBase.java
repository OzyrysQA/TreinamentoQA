package bergs.Cap.Capuaajm.main.java.framework;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;

import bergs.Cap.Capuaajm.main.java.framework.browser.DriverManager;
import bergs.Cap.Capuaajm.main.java.framework.utils.FileOperations;
import bergs.Cap.Capuaajm.main.java.framework.utils.simplereportbuilder.ReportBuilder;




public class TestBase {
    
    protected WebDriver driver;
    
    private static final String UrlWebsiteAlvo = FileOperations
            .getPropertiesTestes("website_config")
            .getProperty("url");

    @BeforeEach
    public void setup() {
        DriverManager.obterDriver().get(TestBase.UrlWebsiteAlvo);
        driver = DriverManager.obterDriver();
        
    }

    @AfterEach
    public void finalizar() {
        DriverManager.finalizarDriver();
        ReportBuilder.concluir();
    }
}
