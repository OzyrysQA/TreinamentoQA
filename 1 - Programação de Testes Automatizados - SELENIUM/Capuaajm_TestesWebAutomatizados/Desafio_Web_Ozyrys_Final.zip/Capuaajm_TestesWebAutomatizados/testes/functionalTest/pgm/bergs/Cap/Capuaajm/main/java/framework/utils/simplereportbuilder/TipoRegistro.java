package bergs.Cap.Capuaajm.main.java.framework.utils.simplereportbuilder;

public enum TipoRegistro {
	SUCESSO,
	FALHA,
}
