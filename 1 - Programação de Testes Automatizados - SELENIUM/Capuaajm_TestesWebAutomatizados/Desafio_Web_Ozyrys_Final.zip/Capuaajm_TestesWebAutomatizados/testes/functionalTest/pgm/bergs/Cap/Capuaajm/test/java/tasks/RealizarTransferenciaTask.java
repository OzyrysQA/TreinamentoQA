package bergs.Cap.Capuaajm.test.java.tasks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import bergs.Cap.Capuaajm.main.java.framework.utils.simplereportbuilder.ReportBuilder;
import bergs.Cap.Capuaajm.test.java.pageobjects.HomePage;
import bergs.Cap.Capuaajm.test.java.pageobjects.LoginCadastroPage;
import bergs.Cap.Capuaajm.test.java.pageobjects.TransferenciaPage;

public class RealizarTransferenciaTask {

    private WebDriver driver;

    private TransferenciaPage transferenciaPage;
    private HomePage homePage;

    // Instancia classe Task armazenando driver e instanciando PageObject da Task
    public RealizarTransferenciaTask(WebDriver driver) {
        this.driver = driver;
        this.homePage = new HomePage(this.driver);
        this.transferenciaPage = new TransferenciaPage(this.driver);

    }
    
    public String clicarTransferencia() {
        transferenciaPage = homePage.clickTransferButton();
        ReportBuilder.addStep("Clicou no Bot�o de Transfer�ncia");
        return transferenciaPage.getTextTransferencia();
        
    }
    
    
    public String realizarTransferencia(String contaOrigem, String contaDestino, Integer valor) throws InterruptedException {
        
        String[] partesContaDestino = contaDestino.split("-");
        String numeroContaDestino = partesContaDestino[0];
        String digitoContaDestino = partesContaDestino[1];
        
        transferenciaPage.setAccountNumber(numeroContaDestino);
        transferenciaPage.setDigit(digitoContaDestino);
        transferenciaPage.setTransferValue(valor.toString());
        transferenciaPage.setDescription(String.format("Transferindo R$ 500 da Conta %s para a Conta %s", contaOrigem, contaDestino));
        ReportBuilder.addStep("Informou Dados para a Transfer�ncia");
        transferenciaPage.clickTransferNowButton();
        
        ReportBuilder.addStep("Clicou em Transferir Agora");
        String textConfirmacaoTransferencia = transferenciaPage.getModalText();
        ReportBuilder.addStep("Transfer�ncia Confirmada");
        transferenciaPage.clickCloseModalButton();
        ReportBuilder.addStep("Clicou para Fechar Modal de Confirma��o de Transfer�ncia");
        transferenciaPage.clickExitButton();
        ReportBuilder.addStep("Clicou em Sair");
        return textConfirmacaoTransferencia;
        
    }
}
