package bergs.Cap.Capuaajm.test.java.tasks;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import bergs.Cap.Capuaajm.main.java.framework.utils.simplereportbuilder.ReportBuilder;
import bergs.Cap.Capuaajm.test.java.pageobjects.HomePage;
import bergs.Cap.Capuaajm.test.java.pageobjects.LoginCadastroPage;

public class CadastrarNovaContaTask {
    private WebDriver driver;

    private LoginCadastroPage loginCadastroPage;
    private HomePage homePage;

    // Instancia classe Task armazenando driver e instanciando PageObject da Task
    public CadastrarNovaContaTask(WebDriver driver) {
        this.driver = driver;
        this.homePage = new HomePage(this.driver);
        this.loginCadastroPage = new LoginCadastroPage(this.driver);

    }

    public String CadastrarNovaConta(String email, String nome, String senha, Boolean contaComsaldo) throws InterruptedException {

        String numeroContaCriada = "";
        loginCadastroPage.clickRegister();
        ReportBuilder.addStep("Clicou em Registro");
        
        // Limpa campos para estado original
        loginCadastroPage.resetRegisterFields();
        
        // Informa dados de login
        loginCadastroPage.setEmailRegister(email);
        loginCadastroPage.setNameRegister(nome);
        loginCadastroPage.setPasswordRegister(senha);
        loginCadastroPage.setPasswordConfirmationRegister(senha);
        ReportBuilder.addStep(String.format("Informou Dados para Registro da Conta do usu�rio %s", nome));
        if (contaComsaldo) {
            loginCadastroPage.clickToggleAddBalance();
            ReportBuilder.addStep("Ativou Conta com Saldo");
        }
        numeroContaCriada = loginCadastroPage.clickRegisterSubmit();
        ReportBuilder.addStep("Clicou em Cadastrar");
        return numeroContaCriada;

    }

    
    public String fazerLoginConta(String email, String senha, String nome) throws InterruptedException {
        loginCadastroPage.setEmailLogin(email);
        loginCadastroPage.setPasswordLogin(senha);
        ReportBuilder.addStep("Informou Dados para Login");

        // Inicializa a inst�ncia HomePage ap�s fazer o login
        homePage = loginCadastroPage.clickLogin();
        ReportBuilder.addStep("Clicou no Login");
        // Retorna mensagem de bem-vindo
        return homePage.getTextNameHome();

    }
    
    public String pegarSaldoConta() {
        ReportBuilder.addStep("Verificou Saldo da Conta Atual Logada");
        return homePage.getBalanceText();
        
    }
   
    
    
}


