package bergs.Cap.Capuaajm.test.java.pageobjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TransferenciaPage {
    private WebDriver driver;
    private WebDriverWait wait;
    private HomePage homePage;
    
    // Mapeando Elementos da HomePage
    
    // Elemento de valida��o de entrada na p�gina
    private By transferInformationText = By.className("transfer__TextInformation-sc-1yjpf2r-7");
    
    // Bot�o Sair
    private By exitButton = By.id("btnExit");
     
    // Campos da Transfer�ncia
    private By accountNumberField = By.name("accountNumber");
    private By digitField = By.name("digit");
    private By transferValueField = By.name("transferValue");
    private By descriptionField = By.name("description");
    private By transferNowButton = By.xpath("//button[contains(text(), 'Transferir agora')]");
    
    // Elementos do Modal
    private By modalText = By.id("modalText");
    private By closeModalButton = By.id("btnCloseModal");
    
    public TransferenciaPage(WebDriver driver) {
        this.driver = driver;
        // Utiliza espera impl�cita para driver aguardar at� 10s  
        wait = new WebDriverWait(driver,Duration.ofSeconds(10));

    }
    
    public String getTextTransferencia()
    {
        // Aguarda at� que o texto de informa��o de transfer�ncia esteja vis�vel
        wait.until(ExpectedConditions.visibilityOfElementLocated(transferInformationText));
        WebElement transferInformationTextElement = driver.findElement(transferInformationText);

        // Retorna o texto do elemento
        return transferInformationTextElement.getText();
        
    }
    
    public WebElement setAccountNumber(String accountNumber) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(accountNumberField));
        WebElement accountNumberFieldElement = driver.findElement(accountNumberField);
        accountNumberFieldElement.sendKeys(accountNumber);
        return accountNumberFieldElement;
        
        
    }
    
    public WebElement setDigit(String digit) {
        WebElement digitFieldElement = driver.findElement(digitField);
        digitFieldElement.sendKeys(digit);
        return digitFieldElement;
    }

    public WebElement setTransferValue(String transferValue) {
        WebElement transferValueFieldElement = driver.findElement(transferValueField);
        transferValueFieldElement.sendKeys(transferValue);
        return transferValueFieldElement;
    }

    public WebElement setDescription(String description) {
        WebElement descriptionFieldElement = driver.findElement(descriptionField);
        descriptionFieldElement.sendKeys(description);
        return descriptionFieldElement;
    }

    public WebElement clickTransferNowButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(transferNowButton));
        WebElement transferNowButtonElement = driver.findElement(transferNowButton);
        transferNowButtonElement.click();
        return transferNowButtonElement;
    }
    
    public String getModalText() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(modalText));
        WebElement modalTextElement = driver.findElement(modalText);
        return modalTextElement.getText();
    }

    public WebElement clickCloseModalButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(closeModalButton));
        WebElement closeModalButtonElement = driver.findElement(closeModalButton);
        closeModalButtonElement.click();
        return closeModalButtonElement;
    }
    
    
    public void clickExitButton() {
        WebElement exitButtonElement = driver.findElement(exitButton);
        exitButtonElement.click();
    }
    
}
