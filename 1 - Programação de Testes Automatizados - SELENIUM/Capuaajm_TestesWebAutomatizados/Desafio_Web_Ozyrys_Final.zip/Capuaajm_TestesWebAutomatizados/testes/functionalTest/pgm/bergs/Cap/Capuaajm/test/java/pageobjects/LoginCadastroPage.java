package bergs.Cap.Capuaajm.test.java.pageobjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginCadastroPage {
    
    private WebDriver driver;
    private WebDriverWait wait;
    private HomePage homePage;
    
    public LoginCadastroPage(WebDriver driver) {
        this.driver = driver;
        // Utiliza espera impl�cita para driver aguardar at� 10s  
        wait = new WebDriverWait(driver,Duration.ofSeconds(10));

    }
    
    // Mapeamento de elementos
    
    // Campos DIV card__login
    private By loginCardDiv = By.className("card__login");
    private By emailFieldLogin = By.xpath("//div[@class='card__login']//input[@name='email']");
    private By passwordFieldLogin = By.xpath("//div[@class='card__login']//input[@name='password']");
    private By loginButton = By.xpath("//div[@class='card__login']//button[contains(text(), 'Acessar')]");
    private By registerButton = By.xpath("//div[@class='card__login']//button[contains(text(), 'Registrar')]");
    private By requirementsLink = By.xpath("//div[@class='card__login']//a[contains(text(), 'Conhe�a nossos requisitos')]");

    // Campos DIV card__register
    private By registerCardDiv = By.className("card__register");
    private By backButtonRegister = By.id("btnBackButton");
    private By emailFieldRegister = By.xpath("//div[@class='card__register']//input[@name='email']");
    private By nameFieldRegister = By.xpath("//div[@class='card__register']//input[@name='name']");
    private By passwordFieldRegister = By.xpath("//div[@class='card__register']//input[@name='password']");
    private By passwordConfirmationFieldRegister = By.xpath("//div[@class='card__register']//input[@name='passwordConfirmation']");
    private By toggleAddBalanceContainer = By.xpath("//div[contains(@class, 'styles__ContainerToggle-sc-7fhc7g-2')]//label[contains(@class, 'styles__Container-sc-1pngcbh-0')]");
    private By toggleAddBalance = By.xpath("//div[contains(@class, 'styles__ContainerToggle-sc-7fhc7g-2')]//label[@id='toggleAddBalance']");
    private By toggleAddBalanceActive = By.xpath("//div[contains(@class, 'styles__ContainerToggle-sc-7fhc7g-2')]//span[contains(@class, 'gXFUUF')]");
    private By registerSubmitButton = By.xpath("//div[@class='card__register']//button[contains(text(), 'Cadastrar')]");

    // Campos DIV MODAL
    private By modalText = By.id("modalText");
    private By closeModalButton = By.id("btnCloseModal");

    
  
    
    // M�todos para interagir com os elementos
    public WebElement setEmailLogin(String email) {
        WebElement emailElement = driver.findElement(emailFieldLogin);
        emailElement.sendKeys(email);
        return emailElement;
    }

    public WebElement setPasswordLogin(String password) {
        WebElement passwordElement = driver.findElement(passwordFieldLogin);
        passwordElement.sendKeys(password);
        return passwordElement;
    }

    public HomePage clickLogin() {
        WebElement loginButtonElement = driver.findElement(loginButton);
        loginButtonElement.click();
        homePage = new HomePage(driver);
        return homePage;
    }

    public WebElement clickRegister() {
        WebElement registerButtonElement = driver.findElement(registerButton);
        registerButtonElement.click();
        // Aguarda at� a div de Cadastro aparecer
        wait.until(ExpectedConditions.visibilityOfElementLocated(registerCardDiv));
        WebElement registerCardDivElement = driver.findElement(registerCardDiv);
        return registerCardDivElement;
    }

    // TODO retornar a RequirementsPage
    public void clickRequirementsLink() {
        WebElement requirementsLinkElement = driver.findElement(requirementsLink);
        requirementsLinkElement.click();
    }

    public WebElement clickBackButtonRegister() {
        WebElement backButtonElement = driver.findElement(backButtonRegister);
        backButtonElement.click();
        // Aguarda at� a div de Login aparecer
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginCardDiv));
        WebElement loginCardDivElement = driver.findElement(loginCardDiv);
        return loginCardDivElement;
    }

    public WebElement setEmailRegister(String email) {
        // Aguarda at� o campo de e-mail aparecer
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailFieldRegister));
        WebElement emailElement = driver.findElement(emailFieldRegister);
        emailElement.sendKeys(email);
        return emailElement;
    }

    public WebElement setNameRegister(String name) {
        WebElement nameElement = driver.findElement(nameFieldRegister);
        nameElement.sendKeys(name);
        return nameElement;
    }

    public WebElement setPasswordRegister(String password) {
        WebElement passwordElement = driver.findElement(passwordFieldRegister);
        passwordElement.sendKeys(password);
        return passwordElement;
    }

    public WebElement setPasswordConfirmationRegister(String passwordConfirmation) {
        WebElement passwordConfirmationElement = driver.findElement(passwordConfirmationFieldRegister);
        passwordConfirmationElement.sendKeys(passwordConfirmation);
        return passwordConfirmationElement;
        
    }
    
    //Clica na op��o de criar conta com saldo
    public WebElement clickToggleAddBalance() throws InterruptedException {
        // Aguarda at� o elemento ser vis�vel
        //wait.until(ExpectedConditions.visibilityOfElementLocated(toggleAddBalance));
        Thread.sleep(3000);
        WebElement toggleAddBalanceElement = driver.findElement(toggleAddBalance);
        toggleAddBalanceElement.click();
        
        // Aguarda at� que a classe do elemento mude
        wait.until(ExpectedConditions.visibilityOfElementLocated(toggleAddBalanceActive));
        WebElement toggleAddBalanceElementActive = driver.findElement(toggleAddBalanceActive);
        //Retorna o toggleAddBalanceChanged ap�s ele mudar a classe
        return toggleAddBalanceElementActive;
    }
    // Desativa op��o de criar a conta com saldo
    public WebElement clickToggleAddBalanceActive() throws InterruptedException {
        // Aguarda at� o elemento ser vis�vel
        //wait.until(ExpectedConditions.visibilityOf(toggleAddBalanceActive));
        Thread.sleep(3000);
        WebElement toggleAddBalanceElementActive = driver.findElement(toggleAddBalanceActive);
        toggleAddBalanceElementActive.click();
        
     // Aguarda at� que a classe do elemento mude
        wait.until(ExpectedConditions.visibilityOfElementLocated(toggleAddBalance));
        WebElement toggleAddBalanceElement = driver.findElement(toggleAddBalance);
        //Retorna o toggleAddBalance ap�s ele voltar ao estado normal desativado
        return toggleAddBalanceElement;
       
    }
    
    public String clickRegisterSubmit() {
        WebElement registerSubmitButtonElement = driver.findElement(registerSubmitButton);
        registerSubmitButtonElement.click();
        
        // Aguarda at� que o texto do modal esteja vis�vel
        wait.until(ExpectedConditions.visibilityOfElementLocated(modalText));
        WebElement modalTextElement = driver.findElement(modalText);

        // Extrai o n�mero da conta do texto do modal
        String modalText = modalTextElement.getText();
        String accountNumber = modalText.substring(modalText.indexOf("conta") + 6, modalText.indexOf("foi") - 1);

        // Clica no bot�o para fechar o modal
        WebElement closeModalButtonElement = driver.findElement(closeModalButton);
        closeModalButtonElement.click();

        // Retorna o n�mero da conta
        return accountNumber;
    }
    
    // M�todo para resetar e limpar formul�rio de registro
    public void resetRegisterFields() throws InterruptedException {
        
        // Limpa os campos de registro
        driver.findElement(emailFieldRegister).clear();
        driver.findElement(nameFieldRegister).clear();
        driver.findElement(passwordFieldRegister).clear();
        driver.findElement(passwordConfirmationFieldRegister).clear();

        // Verifica se o toggleAddBalance est� ativo
        WebElement toggleContainer = driver.findElement(toggleAddBalanceContainer);
        Thread.sleep(3000);
        WebElement toggleAddBalanceElement = driver.findElement(toggleAddBalance);
        if (toggleContainer.getAttribute("class").contains("hsmFIT")) {
            // Se estiver ativo, clica nele para desativar
            driver.findElement(toggleAddBalance).click();
            Thread.sleep(3000);
        }
    }
    
    
}



