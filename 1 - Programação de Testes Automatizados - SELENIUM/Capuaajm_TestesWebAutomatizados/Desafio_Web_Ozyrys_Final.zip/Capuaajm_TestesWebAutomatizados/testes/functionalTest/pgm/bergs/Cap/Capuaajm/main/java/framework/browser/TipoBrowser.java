package bergs.Cap.Capuaajm.main.java.framework.browser;

public enum TipoBrowser {
    CHROME,
    EDGE,
    HEADLESS,
}
