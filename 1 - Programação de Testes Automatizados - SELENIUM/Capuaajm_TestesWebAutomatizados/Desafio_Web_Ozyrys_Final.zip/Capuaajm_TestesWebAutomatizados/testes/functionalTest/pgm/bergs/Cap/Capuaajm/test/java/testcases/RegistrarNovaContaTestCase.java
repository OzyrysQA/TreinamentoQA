package bergs.Cap.Capuaajm.test.java.testcases;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

import bergs.Cap.Capuaajm.main.java.framework.TestBase;
import bergs.Cap.Capuaajm.main.java.framework.browser.DriverManager;
import bergs.Cap.Capuaajm.main.java.framework.utils.simplereportbuilder.ReportBuilder;
import bergs.Cap.Capuaajm.main.java.framework.utils.simplereportbuilder.TipoRegistro;
import bergs.Cap.Capuaajm.test.java.pageobjects.HomePage;
import bergs.Cap.Capuaajm.test.java.pageobjects.LoginCadastroPage;
import bergs.Cap.Capuaajm.test.java.tasks.CadastrarNovaContaTask;
import bergs.Cap.Capuaajm.test.java.tasks.RealizarTransferenciaTask;

public class RegistrarNovaContaTestCase extends TestBase {
    private CadastrarNovaContaTask cadastrarNovaContaTask;
    private RealizarTransferenciaTask realizarTransferenciaTask;
    
    private String numeroConta1;
    private String numeroConta2;
    
    
    /* Desafio Web - Exerc�cio 1
        - Abrir a p�gina inicial da aplica��o web - OK
        - Clicar no bot�o Registrar- OK
        - Preencher o formul�rio de registro com informa��es v�lidas do usu�rio (E-mail, Nome, Senha e Confirma��o senha).- OK
        - Ativar a op��o Criar conta com saldo?- OK
        - Clicar no bot�o Cadastrar - OK
        - Clicar no bot�o Fechar da mensagem criada com sucesso - OK
        - Preencher o formul�rio de acesso com informa��es v�lidas da conta do usu�rio (E-mail e Senha) - OK
        - Clicar no bot�o Acessar - OK
        - Ap�s o acesso, uma tela de gest�o da conta deve ser exibida contendo um elemento Saldo em conta - OK
     */
    @Test
    public void testarCadastrarConta1() throws InterruptedException
    {
        ReportBuilder.criar("Relat�rio Bug Bank Ozyrys Vers�o 1.0", "Cadastrar Nova Conta 1, Realizar Login e Validar se a Conta foi Criada");
        // Instancia TASK
        cadastrarNovaContaTask = new CadastrarNovaContaTask(driver);
        // Executa TASK de Cadastrar Nova Conta 1
        String numeroContaCriada = cadastrarNovaContaTask.CadastrarNovaConta("ozyrys.poa@gmail.com","Ozyrys","voce1234", true);
        System.out.println(numeroContaCriada);
        // Valida se retornou o n�mero da conta criada
        assertNotEquals("",numeroContaCriada);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, String.format("Conta %s criada com sucesso!", numeroContaCriada));
        
        // Guarda o n�mero da conta em uma vari�vel para uso posterior
        numeroConta1 = numeroContaCriada;
        
        String textNameP = cadastrarNovaContaTask.fazerLoginConta("ozyrys.poa@gmail.com", "voce1234", "Ozyrys");
        // Valida se realmente logou pela mensagem de bem vindo
        System.out.println(textNameP);
        assertEquals("Ol� Ozyrys,", textNameP);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Login realizado com sucesso!");
        
        // Valida Saldo Conta 1
        String valorSaldoConta1 = cadastrarNovaContaTask.pegarSaldoConta();
        System.out.println(valorSaldoConta1);
        assertEquals("R$ 1.000,00",valorSaldoConta1);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Saldo Conta 1 Validado com Sucesso Ap�s Cadastro!");
        
    }
    
    /* Desafio Web - Exerc�cio 2
     * Abrir a p�gina inicial da aplica��o web
        - Preencher o formul�rio de acesso com informa��es v�lidas da conta de usu�rio origin�ria (E-mail e Senha) - OK
        - Clicar no bot�o Acessar - OK
        - Clicar no bot�o Transfer�ncia - OK
        - Preencher o formul�rio de transfer�ncia com informa��es v�lidas para execu��o da transfer�ncia (N�mero da conta de usu�rio destinat�ria, D�gito da conta de usu�rio destinat�ria, Valor e Descri��o) - O valor deve ser de R$ 500,00  - OK
        - Clicar no bot�o Transferir agora  - OK
        - Clicar no bot�o Fechar da mensagem realizada com sucesso - OK  
        - Clicar no bot�o Sair - OK
        - Preencher o formul�rio de acesso com informa��es v�lidas da conta de usu�rio destinat�ria (E-mail e Senha) - OK
        - Clicar no bot�o Acessar - OK
        - Ap�s o acesso � conta de usu�rio destinat�ria, ela deve estar com Saldo em conta de R$ 500,00 - OK
     */
    @Test
    public void testarCadastrar2Contas_RealizarTransferencia() throws InterruptedException
    {
        // Dados Conta 1
        String email1="ozyrys.poa@gmail.com";
        String nome1 = "Ozyrys";
        String senha1 = "voce1234";

        // Dados Conta 2        
        String email2= "silvano@gmail.com";
        String nome2 = "Silvano";
        String senha2 = "123";
        
        ReportBuilder.criar("Relat�rio Bug Bank Ozyrys Vers�o 1.0", "Cadastrar 2 Contas, Realizar Transfer�ncia da Conta 1 para Conta 2");
        // Instancia TASK
        cadastrarNovaContaTask = new CadastrarNovaContaTask(driver);
        
        
        // Executa TASK de Cadastrar Nova Conta 1
        String numeroContaCriada = cadastrarNovaContaTask.CadastrarNovaConta(email1,nome1,senha1, true);
        System.out.println(numeroContaCriada);
        // Valida se retornou o n�mero da conta criada
        assertNotEquals("",numeroContaCriada);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, String.format("Conta 1 - %s criada com sucesso!", numeroContaCriada));
        // Guarda o n�mero da conta em uma vari�vel para uso posterior
        numeroConta1 = numeroContaCriada;
        
        // Executa TASK de Cadastrar Nova Conta 2
        numeroContaCriada = cadastrarNovaContaTask.CadastrarNovaConta(email2,nome2,senha2, false);
        System.out.println(numeroContaCriada);
        // Valida se retornou o n�mero da conta criada
        assertNotEquals("",numeroContaCriada);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, String.format("Conta 2 - %s criada com sucesso!", numeroContaCriada));
        // Guarda o n�mero da conta em uma vari�vel para uso posterior
        numeroConta2 = numeroContaCriada;
        
        // Realiza login na Conta 1 para fazer a transfer�ncia para a Conta 2
        String textNameP = cadastrarNovaContaTask.fazerLoginConta(email1,senha1 , nome1);
        // Valida se realmente logou pela mensagem de bem vindo
        System.out.println(textNameP);
        assertEquals(String.format("Ol� %s,",nome1), textNameP);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Login Conta 1 realizado com sucesso!");
        
        // Valida Saldo Conta 1 Antes da transfer�ncia
        String valorSaldoConta1 = cadastrarNovaContaTask.pegarSaldoConta();
        System.out.println(valorSaldoConta1);
        assertEquals("R$ 1.000,00",valorSaldoConta1);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Saldo Conta 1 Validado com Sucesso antes da Transfer�ncia!");
        
        // Realizar a transfer�ncia da Conta 1 para a Conta 2
        realizarTransferenciaTask = new RealizarTransferenciaTask(driver);
        String textTransferenciaP = realizarTransferenciaTask.clicarTransferencia();
        System.out.println(textTransferenciaP);
        assertEquals("Realize transfer�ncia de valores entre contas BugBank com taxa 0 e em poucos segundos.", textTransferenciaP);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Acessou a p�gina de transfer�ncia com sucesso!");
        
        String confirmacaoTransferencia = realizarTransferenciaTask.realizarTransferencia(numeroConta1, numeroConta2, 500);
        System.out.println(confirmacaoTransferencia);
        assertEquals("Transferencia realizada com sucesso", confirmacaoTransferencia);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, String.format("Transfer�ncia de R$ 500 da Conta %s para a Conta %s Realizada com Sucesso!", numeroConta1, numeroConta2));
        
        
        // Realiza login na Conta 2 para confirmar a transfer�ncia realizada
        textNameP = cadastrarNovaContaTask.fazerLoginConta(email2,senha2 , nome2);
        // Valida se realmente logou pela mensagem de bem vindo
        System.out.println(textNameP);
        assertEquals(String.format("Ol� %s,",nome2), textNameP);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Login Conta 2 realizado com sucesso!");
        
        // Valida Saldo da Conta 2 Ap�s a Transfer�ncia
        String valorSaldoConta2 = cadastrarNovaContaTask.pegarSaldoConta();
        System.out.println(valorSaldoConta2);
        assertEquals("R$ 500,00",valorSaldoConta2);
        ReportBuilder.addRegistro(TipoRegistro.SUCESSO, "Saldo Conta 2 Validado com Sucesso ap�s Transfer�ncia!");
        
    }
    
    
}
