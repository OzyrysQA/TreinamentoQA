package bergs.Cap.Capuaajm.test.java.validations;


public class LoginValidation {

}
