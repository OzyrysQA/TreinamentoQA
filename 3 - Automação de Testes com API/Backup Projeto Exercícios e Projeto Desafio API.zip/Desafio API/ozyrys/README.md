![Logo](logo.png)

# Boilerplate Java para Automação de Testes de APIs

O boilerplate Java para automação de testes de APIs contém um conjunto inicial de recursos que possibilitam um rápido e simplificado início de construção de testes automatizados. <!-- TODO: SOM [...] utilizando a proposta "Banrisul" do modelo [ServiceObject](https://www.linkedin.com/pulse/service-object-model-itay-melamed). -->

## Getting started

### Pré-requisitos

- [Java SE Development Kit 11](https://www.oracle.com/br/java/technologies/downloads/#java11) ou superior

### Workspace

O workspace contém a seguinte estrutura:

```shell
.
├── Capkcfjm_configuracao
│   └── gradle
└── Capuaajm_TestesAPIAutomatizados
    ├── relatorios_testes
    └── testes
        └── functionalTest
            └── pgm
                └── bergs
                    └── Cap
                        └── Capuaajm
                            ├── main
                            │   ├── java
                            │   │   ├── app
                            │   │   └── framework
                            │   └── resources
                            └── test
                                ├── java
                                │   └── testcases
                                └── resources
```
<!-- TODO: SOM [...] 
    └── test
        ├── java
        │   ├── services
        │   └── testcases
        └── resources
[...] -->

- `Capkcfjm_configuracao` - Local dos arquivos de configuração da codebase
  - `gradle` - Local da distribuição Gradle em utilização no projeto (Gradle Wrapper)
- `Capuaajm_TestesAPIAutomatizados` - Local dos arquivos de código fonte da codebase
  - `relatorios_testes` - Local dos relatórios de execução de testes automaticamente gerados pela estrutura
  - `testes/functionalTest/pgm/bergs/Cap/Capuaajm/main` - Local que centraliza a parte da codebase a ser executada em formato de aplicação convencional (Java ou outras)
    - `java/app` - Local do web server que provê uma aplicação web + API de exemplo (cujos arquivos HTML, JavaScript, CSS e API JSON estão em `main/resources/app`)
    - `java/framework` - Local da parte base do framework para automação de testes
    - `resources` - Local de arquivos utilitários (ex.: arquivos da aplicação web + API de exemplo, arquivos de dados, arquivos de propriedades para a aplicação)
  - `testes/functionalTest/pgm/bergs/Cap/Capuaajm/test` - Local que centraliza a parte da codebase a ser executada em formato de testes (Java ou outras, via frameworks como por exemplo JUnit)
    <!-- TODO: SOM 
    - `java/services` - Local complementar ao framework para automação de testes que possui as classes que representam os serviços das APIs alvo (ex.: aplicação provida pelo web server em `main/java/app`)
    [...] -->
    - `java/testcases` - Local complementar ao framework para automação de testes que possui as classes que representam os casos de teste de fato <!-- TODO: SOM [...], executados através do uso de `test/java/services` -->
    - `resources` - Local de arquivos utilitários para os testes (ex.: arquivos de dados, output padrão de relatórios de execução de testes, arquivos de propriedades para os testes)

> [!NOTE]
> * `Capkcfjm` e `Capuaajm` são acrônimos de um conjunto de projetos, times e setores do Banrisul. A exemplo, o `Cap` contido nestes, refere-se à própria **Cap**acitação
> * A estrutura intermediária `testes/functionalTest/pgm/bergs/Cap/Capuaajm` espelha padrões utilizados dentro da organização, mas, para fins de projeto, neste momento não entrega efeitos práticos relevantes
> * As pastas intermediárias `java` contidas em `main` e `test` tem propósito de centralizar os arquivos Java. Essa convenção ajuda na organização do código e é flexível para suportar outras linguagens (Gradle suporta ambientes multi-linguagem). Se houvessem também arquivos em uma linguagem diferente, como por exemplo Kotlin, também poderia haver uma pasta correspondente (ex.: `kotlin`)

### Executando o projeto

#### 1. Aplicação

##### 1.1 Via terminal de comandos

Executar o arquivo `gradlew` (Gradle Wrapper) para atualizar (sincronizar) as dependências configuradas no projeto
```shell
./Capkcfjm_configuracao/gradlew --refresh-dependencies
```

Executar o arquivo `gradlew` (Gradle Wrapper) usando a task **run** 
```shell
./Capkcfjm_configuracao/gradlew run
```

#### 2. Testes

##### 2.1 Via terminal de comandos

Executar o arquivo `gradlew` (Gradle Wrapper) para atualizar (sincronizar) as dependências configuradas no projeto
```shell
./Capkcfjm_configuracao/gradlew --refresh-dependencies
```

Executar o arquivo `gradlew` (Gradle Wrapper) usando a task **test** 
```shell
./Capkcfjm_configuracao/gradlew test
```

# Desafio Automação DBBank

A API [DBBank](https://bugbank.netlify.app) simula um módulo financeiro, possibilitando registros de contas de usuário que também funcionam como contas bancárias capazes de efetuar transferências de valores monetários para outras contas também registradas.


## Desafio

### 1. Automation Request

#### Caso de Teste (TC - Test Case):

Registro de uma nova conta de usuário

#### Descrição:

Validar o registro de uma nova conta de usuário através de uma tentativa de acesso bem sucedida.

#### Pré-Condições:

- A API deve estar acessível
- O usuário ainda não deve ter uma conta registrada

#### Passos:

1. Efetuar o registro enviando uma requisição POST para o endpoint de contas com informações válidas do usuário (E-mail, Nome, Senha e Confirmação senha)
    - Certificar-se também de setar a informação de saldo inicial com um valor superior a 0 (zero)
2. Efetuar o acesso da conta do usuário enviando uma requisição POST para o endpoint de acesso com informações válidas da mesma (E-mail e Senha)

#### Resultados Esperados:

- A resposta para a requisição de registro deve conter um [HTTP status code](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status) [201](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/201)
- A resposta para a requisição de acesso deve conter um [HTTP status code](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status) [200](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/200), e o [payload](https://developer.mozilla.org/en-US/docs/Glossary/Payload_body) da resposta deve conter em sua estrutura JSON uma propriedade *saldo*, contendo o mesmo valor apontado na requisição de registro

#### Pós-Condições:

- O usuário deve estar com a nova conta registrada e ter a acessado com sucesso

### 2. Automation Request

#### Caso de Teste (TC - Test Case):

Transferência de valores monetários entre contas de usuário

#### Descrição:

Validar em uma conta de usuário destinatária a entrada de um valor monetário proveniente de uma conta de usuário originária.

#### Pré-Condições:

- A API deve estar acessível
- Devem haver duas contas de usuário já registradas (originária e destinatária), tendo a conta originária um *saldo* de R$ 1000,00, e a conta destinatária um *saldo* de R$ 0,00

#### Passos:

1. Efetuar o acesso da conta de usuário originária enviando uma requisição POST para o endpoint de acesso com informações válidas da mesma (E-mail e Senha)
2. Realizar uma transferência enviando uma requisição POST para o endpoint de transferências com informações válidas para a sua realização (Número da conta de usuário destinatária, Dígito da conta de usuário destinatária, Valor e Descrição) - O valor deve ser de R$ 500,00
3. Efetuar a obtenção dos detalhes da conta de usuário originária enviando uma requisição GET para o endpoint de contas
4. Efetuar o acesso da conta de usuário destinatária enviando uma requisição POST para o endpoint de acesso com informações válidas da mesma (E-mail e Senha)
5. Efetuar a obtenção dos detalhes da conta de usuário destinatária enviando uma requisição GET para o endpoint de contas

> [!NOTE]
> - A resposta das requisições de acesso contém na estrutura JSON do seu [payload](https://developer.mozilla.org/en-US/docs/Glossary/Payload_body) um token (propriedade *accessToken*) que deve ser enviado em requisições para endpoints protegidos, através de um [Authorization header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) de esquema do tipo [bearer](https://swagger.io/docs/specification/authentication/bearer-authentication)
> - Endpoints protegidos:
>   - GET - Obtenção de detalhes da conta
>   - POST - Realização de transferências

#### Resultados Esperados:

- O *saldo* contido na estrutura JSON do [payload](https://developer.mozilla.org/en-US/docs/Glossary/Payload_body) da resposta da requisição de obtenção dos detalhes da conta de usuário originária deve ser de R$ 500,00
- O *saldo* contido na estrutura JSON do [payload](https://developer.mozilla.org/en-US/docs/Glossary/Payload_body) da resposta da requisição de obtenção dos detalhes da conta de usuário destinatária deve ser de R$ 500,00

#### Pós-Condições:

- As duas contas de usuário devem estar com valores iguais de *saldo*
