package bergs.Cap.Capuaajm.test.java.testcases;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import org.junit.jupiter.api.Test;

import bergs.Cap.Capuaajm.main.java.framework.TestBase;

public class ChecarSaudeAplicacaoTestCase extends TestBase {

    private static final String JSON = "application/json; charset=utf-8";
    
    /*DADOS USU�RIO 1:
     * {
          "email": "ozyrys.poa@gmail.com",
          "nome": "Ozyrys",
          "senha": "voce1234",
          "confirmacaoSenha": "voce1234",
          "saldoInicial": 1000
       }*/
    
    /*DADOS USU�RIO 2:
     * {
          "email": "silvano@gmail.com",
          "nome": "Silvano",
          "senha": "1234",
          "confirmacaoSenha": "1234",
          "saldoInicial": 0
       }
     */
    
    @Test
    public void testCreateUsuarios() {

        //Header header = new Header("x-access-token", obterTokenAuth());
        String nomeUsuarioCriado = given()
                .baseUri(URL)
                //.request().header(header)
                .request().body("{\n"
                        + "          \"email\": \"ozyrys.poa@gmail.com\",\n"
                        + "          \"nome\": \"Ozyrys\",\n"
                        + "          \"senha\": \"voce1234\",\n"
                        + "          \"confirmacaoSenha\": \"voce1234\",\n"
                        + "          \"saldoInicial\": 1000\n"
                        + "       }")
                .contentType(JSON)
                .when()
                .post("/contas")
                .then()
                .assertThat().statusCode(is(201))
                .assertThat().contentType(JSON)
                .assertThat().body("usuario", is(notNullValue()))
                .and()
                .extract()
                .path("usuario.nome");
       System.out.println(String.format("Nome Usu�rio 1 Criado: %s",nomeUsuarioCriado) );
    }
    
}
