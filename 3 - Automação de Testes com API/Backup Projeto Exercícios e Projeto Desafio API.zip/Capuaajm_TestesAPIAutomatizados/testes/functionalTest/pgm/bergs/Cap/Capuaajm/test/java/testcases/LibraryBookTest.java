package bergs.Cap.Capuaajm.test.java.testcases;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.util.ArrayList;

import org.apache.commons.lang3.NotImplementedException;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import bergs.Cap.Capuaajm.main.java.framework.TestBase;
import io.restassured.http.Header;

public class LibraryBookTest extends TestBase {

    private static final String JSON = "application/json; charset=utf-8";

    /*DADOS USU�RIO 1:
     * {
          "email": "ozyrys.poa@gmail.com",
          "nome": "Ozyrys",
          "senha": "voce1234",
          "confirmacaoSenha": "voce1234",
          "saldoInicial": 1000
       }*/
    
    /*DADOS USU�RIO 2:
     * {
          "email": "silvano@gmail.com",
          "nome": "Silvano",
          "senha": "1234",
          "confirmacaoSenha": "1234",
          "saldoInicial": 0
       }
     */
    
    @Test
    public void testCreateUsuarios() {

        //Header header = new Header("x-access-token", obterTokenAuth());
        String nomeUsuarioCriado = given()
                .baseUri(URL)
                //.request().header(header)
                .request().body("{\n"
                        + "          \"email\": \"ozyrys.poa@gmail.com\",\n"
                        + "          \"nome\": \"Ozyrys\",\n"
                        + "          \"senha\": \"voce1234\",\n"
                        + "          \"confirmacaoSenha\": \"voce1234\",\n"
                        + "          \"saldoInicial\": 1000\n"
                        + "       }")
                .contentType(JSON)
                .when()
                .post("/contas")
                .then()
                .assertThat().statusCode(is(201))
                .assertThat().contentType(JSON)
                .assertThat().body("usuario", is(notNullValue()))
                .and()
                .extract()
                .path("usuario.nome");
       System.out.println(String.format("Nome Usu�rio 1 Criado: %s",nomeUsuarioCriado) );
    }
    
    
    @Test
    public void testListAllBooks_Sucesso() {

        ArrayList<String> bookList = new ArrayList<>();
        bookList = given().baseUri(URL).when().get("/books")
                .then()
                    .assertThat().statusCode(is(200))
                    .assertThat().contentType(is(JSON))
                .and()
                    .extract().as(bookList.getClass());
      
        System.out.println(bookList);

    }

    @Test
    public void testListBooksByAuthor_Sucesso() {
        String author = "Lucifer";

        ArrayList<String> bookList = new ArrayList<>();
        bookList = given().baseUri(URL)
                .param("search", author)
                .when().get("/books").then()
                    .assertThat().statusCode(is(200))
                    .assertThat().contentType(is(JSON)).and().extract().as(bookList.getClass());
        System.out.println(bookList);
    }

    @Test
    public void testListAllBooksTitles_Sucesso() {

        ArrayList<String> bookList = new ArrayList<>();
        bookList = given().baseUri(URL).when().get("/books").then().assertThat().statusCode(is(200)).assertThat().contentType(is(JSON))
                .and()
                .extract()
                .path("title");

        System.out.println(bookList);

    }

    public String obterTokenAuth() {

        String token = given()
                .baseUri(URL)
                .request().body("{\"usr\":\"Ozyrys\",\"pwd\":\"voce1234\"}")
                .contentType(JSON)
                .when()
                .post("/auth")
                .then()
                .assertThat().statusCode(is(200))
                .assertThat().contentType(JSON)
                .assertThat().body("token", is(notNullValue()))
                .and()
                .extract()
                .path("token");
        return token;
    }

    @Test
    public void testCreateBook_Sucesso() {

        Header header = new Header("x-access-token", obterTokenAuth());
        String idLivroCriado = given()
                .baseUri(URL)
                .request().header(header)
                .request().body("{\"isbn\": \"1-1-1\",\r\n"
                        + "        \"title\": \"Teste Novo Livro\",\r\n"
                        + "        \"author\": \"Lucifer Jr.\",\r\n"
                        + "        \"publisher\": \"Devil's Editor\",\r\n"
                        + "        \"price\": 333,\r\n"
                        + "        \"stock\": 3,\r\n"
                        + "        \"country\": \"RS\",\r\n"
                        + "        \"img\": \"https://m.media-amazon.com/images/I/81XpG2iKTlL._AC_UF1000,1000_QL80_.jpg\"}")
                .contentType(JSON)
                .when()
                .post("/books")
                .then()
                .assertThat().statusCode(is(201))
                .assertThat().contentType(JSON)
                .assertThat().body("newBook.id", is(notNullValue()))
                .and()
                .extract()
                .path("newBook.id");
        System.out.println("Id livro criado:" + idLivroCriado);
    }

    @Test
    public void testDeleteBook_Sucesso() {

        String id = "57e53cff-f5a2-41ac-8114-278aba383046";
        
        Header header = new Header("x-access-token", obterTokenAuth());
        given()
            .baseUri(URL)
            .request().header(header)
            .request().pathParam("id", id)
        .when()
        .delete("/books/{id}")
        .then()
            .assertThat().statusCode(is(204));

    }
    
    @Test
    public void testListBooksById_Sucesso() {
        String id = "ff5667c4-76d8-46c9-90da-dcfb74d79fa6";

        String book = given().baseUri(URL).pathParam("id",id)
                .when()
                    .get("/books/{id}")
                .then()
                    .assertThat().statusCode(is(200))
                    .assertThat().contentType(is(JSON))
                .and()
                    .extract().asString();
        System.out.println(book);
    }
    
    @Test
    public void testListBooksById_Falha404() {
        String id = "c85521b8-8072-41e5-b1e1-0074b14b753b";

        String book = given().baseUri(URL).pathParam("id",id)
                .when()
                    .get("/books/{id}")
                .then()
                    .assertThat().statusCode(is(404))
                    .assertThat().contentType(is(JSON))
                .and()
                    .extract().asString();
        System.out.println(book);
    }

    @Disabled("API NODE.JS BOOKSTORE N�O POSSUI ENTRADA PUT")
    @Test
    public void testUpdateBook_PUT_Sucesso() {
        String id = "719f8b95-1d83-41ac-9c26-5e6d65b9479";
        Header header = new Header("x-access-token", obterTokenAuth());
        given()
            .baseUri(URL)
            .request().header(header)
            .request().body("{\"isbn\": \"6-6-6\",\r\n"
                    + "        \"title\": \"Number of the Beast\",\r\n"
                    + "        \"author\": \"Alterando o autor\",\r\n"
                    + "        \"publisher\": \"Devil's Editor\",\r\n"
                    + "        \"price\": 666,\r\n"
                    + "        \"stock\": 5,\r\n"
                    + "        \"country\": \"RS\",\r\n"
                    + "        \"img\": \"https://m.media-amazon.com/images/I/81XpG2iKTlL._AC_UF1000,1000_QL80_.jpg\"}")
            .contentType(JSON)
            .when()
            .put("/books/"+ id)
            .then()
            .assertThat().statusCode(is(200))
            .assertThat().contentType(JSON)
            .assertThat().body("updatedBook.author", is("New Author"));
    }

    @Test
    public void testUpdateBook_PATCH_Sucesso() {
        String id = "719f8b95-1d83-41ac-9c26-5e6d65b9479c";
        Header header = new Header("x-access-token", obterTokenAuth());
        given()
            .baseUri(URL)
            .request().header(header)
            .request().body("{\"author\": \"Alterei o autor\"}")
            .contentType(JSON)
            .when()
            .patch("/books/"+ id)
            .then()
            .assertThat().statusCode(is(200))
            .assertThat().contentType(JSON)
            .assertThat().body("updatedBook.author", is("Alterei o autor"));
    }
    
    
}
