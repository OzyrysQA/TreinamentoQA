package bergs.Cap.Capuaajm.test.java.testcases;

import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Assertions;
import static io.restassured.RestAssured.given;
import org.junit.jupiter.api.Test;

import bergs.Cap.Capuaajm.main.java.framework.TestBase;

public class ChecarSaudeAplicacaoTestCase extends TestBase {
    protected static final String JSON = "application/json; charset=utf-8";

    @Test
    public void teste123() {
        System.out.println(URL);
        Assertions.assertTrue(true);
    }
    
    @Test
    public void testeAPI()
    {
        given().baseUri(URL).when().get("/books").then()
        .assertThat().statusCode(is(200))
        .assertThat().contentType(is(JSON))
        .and()
        .extract()
        .path("[0].id");
    }
}
