package bergs.Cap.Capuaajm.test.java.testcases;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.nio.file.Path;
import java.util.ArrayList;

import org.apache.commons.lang3.NotImplementedException;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import bergs.Cap.Capuaajm.main.java.framework.TestBase;
import io.restassured.http.Header;

public class TestDesafioDBBank extends TestBase {

    private static final String JSON = "application/json; charset=utf-8";

    @Test
    public void testDesafioAPI1()
    {
        
        // Cadastra Conta
         given()
                .baseUri(URL)
               .request().body("{\n"
                        + "          \"email\": \"desafio1@gmail.com\",\n"
                        + "          \"nome\": \"desafio1\",\n"
                        + "          \"senha\": \"desafio1\",\n"
                        + "          \"confirmacaoSenha\": \"desafio1\",\n"
                        + "          \"saldoInicial\": 1\n"
                        + "       }")
                .contentType(JSON)
                .when()
                .post("contas")
                .then()
                .assertThat().statusCode(is(201))
                .assertThat().contentType(JSON)
                .assertThat().body("user", is(notNullValue()));
         
         // Realiza login e pega o saldo  da conta 
         String saldoConta =  given()
                 .baseUri(URL)
                 .request().body("{\r\n"
                         + "  \"email\": \"desafio1@gmail.com\",\r\n"
                         + "  \"senha\": \"desafio1\"\r\n"
                         + "}")
                 .contentType(JSON)
                 .when()
                 .post("acesso")
                 .then()
                 .assertThat().statusCode(is(200))
                 .assertThat().contentType(JSON)
                 .assertThat().body("user", is(notNullValue()))
                 .and()
                 .extract()
                 .path("user.saldo").toString();
         
         
         System.out.println(String.format("Saldo Conta Cadastrada: %s",saldoConta) );
       
       
    }
    
    
    //OBS: S� pode executar 1 vez
    public void criarContasUsuarios() {
        String nomeUsuarioCriado1 = "";
        String nomeUsuarioCriado2 = "";
        
            
        nomeUsuarioCriado1 = given()
                .baseUri(URL)
               .request().body("{\n"
                        + "          \"email\": \"ozyrys.poa@gmail.com\",\n"
                        + "          \"nome\": \"Ozyrys\",\n"
                        + "          \"senha\": \"voce1234\",\n"
                        + "          \"confirmacaoSenha\": \"voce1234\",\n"
                        + "          \"saldoInicial\": 1000\n"
                        + "       }")
                .contentType(JSON)
                .when()
                .post("contas")
                .then()
                .assertThat().statusCode(is(201))
                .assertThat().contentType(JSON)
                .assertThat().body("usuario", is(notNullValue()))
                .and()
                .extract()
                .path("usuario.nome");
       System.out.println(String.format("Nome Usu�rio 1 Criado: %s",nomeUsuarioCriado1) );
       
       nomeUsuarioCriado2 = given()
               .baseUri(URL)
              .request().body("{\r\n"
                      + "          \"email\": \"silvano@gmail.com\",\r\n"
                      + "          \"nome\": \"Silvano\",\r\n"
                      + "          \"senha\": \"1234\",\r\n"
                      + "          \"confirmacaoSenha\": \"1234\",\r\n"
                      + "          \"saldoInicial\": 0\r\n"
                      + "       }")
               .contentType(JSON)
               .when()
               .post("contas")
               .then()
               .assertThat().statusCode(is(201))
               .assertThat().contentType(JSON)
               .assertThat().body("usuario", is(notNullValue()))
               .and()
               .extract()
               .path("usuario.nome");
      System.out.println(String.format("Nome Usu�rio 2 Criado: %s",nomeUsuarioCriado2) );
          
    }
    
    @Test
    public void testDesafioAPI2() {
        //EXECUTAR 1 VEZ O M�TODO ABAIXO PARA CRIAR CONTAS, DEPOIS COMENTAR
        criarContasUsuarios();
        
        String contaNumero1 =  given()
                .baseUri(URL)
                .request().body("{\r\n"
                        + "  \"email\": \"ozyrys.poa@gmail.com\",\r\n"
                        + "  \"senha\": \"voce1234\"\r\n"
                        + "}")
                .contentType(JSON)
                .when()
                .post("acesso")
                .then()
                .assertThat().statusCode(is(200))
                .assertThat().contentType(JSON)
                .assertThat().body("user", is(notNullValue()))
                .and()
                .extract()
                .path("user.contaNumero").toString();
        
        String contaDigito1 =  given()
                .baseUri(URL)
                .request().body("{\r\n"
                        + "  \"email\": \"ozyrys.poa@gmail.com\",\r\n"
                        + "  \"senha\": \"voce1234\"\r\n"
                        + "}")
                .contentType(JSON)
                .when()
                .post("acesso")
                .then()
                .assertThat().statusCode(is(200))
                .assertThat().contentType(JSON)
                .assertThat().body("user", is(notNullValue()))
                .and()
                .extract()
                .path("user.contaDigito").toString();
                
       String accessTokenConta1 = given()
               .baseUri(URL)
               .request().body("{\r\n"
                       + "  \"email\": \"ozyrys.poa@gmail.com\",\r\n"
                       + "  \"senha\": \"voce1234\"\r\n"
                       + "}")
               .contentType(JSON)
               .when()
               .post("acesso")
               .then()
               .assertThat().statusCode(is(200))
               .assertThat().contentType(JSON)
               .assertThat().body("user", is(notNullValue()))
               .and()
               .extract()
               .path("accessToken").toString();   
       
       System.out.println(String.format("Token Conta 1 Logada:%s", accessTokenConta1) );
        
       
       String contaNumero2 = given()
               .baseUri(URL)
               .request().body("{\r\n"
                       + "  \"email\": \"silvano@gmail.com\",\r\n"
                       + "  \"senha\": \"1234\"\r\n"
                       + "}")
               .contentType(JSON)
               .when()
               .post("acesso")
               .then()
               .assertThat().statusCode(is(200))
               .assertThat().contentType(JSON)
               .assertThat().body("user", is(notNullValue()))
               .and()
               .extract()
               .path("user.contaNumero").toString();
       
       String contaDigito2 = given()
               .baseUri(URL)
               .request().body("{\r\n"
                       + "  \"email\": \"silvano@gmail.com\",\r\n"
                       + "  \"senha\": \"1234\"\r\n"
                       + "}")
               .contentType(JSON)
               .when()
               .post("acesso")
               .then()
               .assertThat().statusCode(is(200))
               .assertThat().contentType(JSON)
               .assertThat().body("user", is(notNullValue()))
               .and()
               .extract()
               .path("user.contaDigito").toString();
       
      System.out.println(String.format("Dados Conta 2 Logada: %s-%s",contaNumero2 , contaDigito2));
      
      Header header = new Header("Authorization", accessTokenConta1);
      
      String messageConfirmacao =  given()
              .baseUri(URL)
              .request().header(header)
              .body(String.format("{\r\n"
                      + "  \"destino\": \"%s-%s\",\r\n"
                      + "  \"valor\": 500,\r\n"
                      + "  \"descricao\": \"Transferindo R$ 500 reais\"\r\n"
                      + "}",contaNumero2, contaDigito2))
              .contentType(JSON)
              .when()
              .post(String.format("contas/%s-%s/transferencias", contaNumero1, contaDigito1))
              .then()
              .assertThat().statusCode(is(200))
              .assertThat().contentType(JSON)
              .assertThat().body("message", is(notNullValue()))
              .and()
              .extract()
              .path("message").toString();
      
      System.out.println(messageConfirmacao);
      
      
      // Realiza login e pega o saldo  da conta Ozyrys
      String saldoConta1 =  given()
              .baseUri(URL)
              .request().body("{\r\n"
                      + "  \"email\": \"ozyrys.poa@gmail.com\",\r\n"
                      + "  \"senha\": \"voce1234\"\r\n"
                      + "}")
              .contentType(JSON)
              .when()
              .post("acesso")
              .then()
              .assertThat().statusCode(is(200))
              .assertThat().contentType(JSON)
              .assertThat().body("user", is(notNullValue()))
              .and()
              .extract()
              .path("user.saldo").toString();
      
      
      System.out.println(String.format("Saldo Conta Ozyrys: %s",saldoConta1) );
      
   // Realiza login e pega o saldo  da conta Silvano
      String saldoConta2 =  given()
              .baseUri(URL)
              .request().body("{\r\n"
                      + "  \"email\": \"silvano@gmail.com\",\r\n"
                      + "  \"senha\": \"1234\"\r\n"
                      + "}")
              .contentType(JSON)
              .when()
              .post("acesso")
              .then()
              .assertThat().statusCode(is(200))
              .assertThat().contentType(JSON)
              .assertThat().body("user", is(notNullValue()))
              .and()
              .extract()
              .path("user.saldo").toString();
      
      
      System.out.println(String.format("Saldo Conta Silvano: %s",saldoConta2) );
      
      
      String saldoConta2GET =  given()
              .baseUri(URL)
              .request().header(header)
              .contentType(JSON)
              .when()
              .get(String.format("contas/%s-%s", contaNumero2, contaDigito2))
              .then()
              .assertThat().statusCode(is(200))
              .assertThat().contentType(JSON)
              .assertThat().body("user", is(notNullValue()))
              .and()
              .extract()
              .path("user.saldo").toString();
      
      System.out.println(String.format("Saldo Conta 2 Silvano USANDO GET: %s",saldoConta2GET) );
      
    } 
    
}
